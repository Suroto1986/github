echo "# github" >> README.md 
git init 
git add README.md 
git commit -m "first commit" 
git branch -M main 
git remote add Origin https://github.com/Suroto1986/github.git
 git Push - kamu asal main# github
